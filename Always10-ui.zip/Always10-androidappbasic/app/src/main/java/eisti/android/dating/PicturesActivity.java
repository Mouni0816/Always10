package eisti.android.dating;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Paths;

public class PicturesActivity extends AppCompatActivity {

    private Button galleryButton;
    private ImageView bestPicture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pictures);

        galleryButton = (Button) findViewById(R.id.galleryButton);
        bestPicture = (ImageView) findViewById(R.id.bestPicture);

        bestPicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent (Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent,1);

                Toast.makeText(PicturesActivity.this,"Left!",Toast.LENGTH_SHORT).show();

            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==1 && resultCode== Activity.RESULT_OK){
            final Uri imageUri = data.getData();
            bestPicture.setImageURI(imageUri);

            

            //System.out.println(response);
            //Toast.makeText(PicturesActivity.this, response, Toast.LENGTH_SHORT).show();

        }
    }


}